import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <nav>
        <Link to="/">Home</Link> | 
        <Link to="/registration">Registration</Link> | 
        <Link to="/login">Login</Link>
      </nav>

  )
}



