import React from 'react';

function Login() {
  return (
    <div style={{ width: '300px', margin: '50px auto', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
      <h2 className="text-center mb-4">Login</h2>
      <label htmlFor="email" style={{ display: 'block', marginBottom: '8px' }}>Email address</label>
      <input
        type="email"
        id="email"
        placeholder="Enter email"
        style={{ width: '100%', padding: '8px', marginBottom: '16px', borderRadius: '4px', border: '1px solid #ccc' }}
      />
      <label htmlFor="password" style={{ display: 'block', marginBottom: '8px' }}>Password</label>
      <input
        type="password"
        id="password"
        placeholder="Enter password"
        style={{ width: '100%', padding: '8px', marginBottom: '16px', borderRadius: '4px', border: '1px solid #ccc' }}
      />
      <button
        style={{
          width: '100%',
          padding: '10px',
          backgroundColor: '#007bff',
          color: '#fff',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
        }}
      >
        Login
      </button>
    </div>
  );
}

export default Login;
